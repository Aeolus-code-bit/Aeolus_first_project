.\objects\color.o: Hardware\Color.c
