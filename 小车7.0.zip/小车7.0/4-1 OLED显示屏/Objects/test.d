.\objects\test.o: Hardware\Test.c
